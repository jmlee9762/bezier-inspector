Bézier Inspector Free Distribution v1.0.2

이 패키지는 무료 배포용으로 구성되어 있습니다.
Apple Developer ID가 없어도 쓸 수 있도록 .app 설치기를 제거하고,
아래 2가지 설치 경로를 같이 제공합니다.

1) 추천: install.sh 설치
   - 일반 사용자에게 가장 안정적인 무료 설치 방식입니다.
   - 기존 중복 설치 제거, 올바른 CEP 경로 복사, quarantine 제거,
     PlayerDebugMode 설정, CEP cache 정리를 자동 처리합니다.

2) 선택: self-signed ZXP 생성 후 설치
   - scripts/build_zxp_self_signed.sh 로 bezier_inspector.zxp를 생성합니다.
   - 이 환경에는 Adobe ZXPSignCmd가 없어서 완성된 signed ZXP는 포함하지 않았습니다.
   - 네 Mac에서 ZXPSignCmd를 tools/ZXPSignCmd 위치에 넣고 빌드해야 합니다.

빠른 설치:

  1. Illustrator를 완전히 종료
  2. 이 ZIP 압축 해제
  3. Terminal 열기
  4. 압축 해제 폴더로 이동
  5. 실행:

     bash install.sh

  6. Illustrator 재시작
  7. Window → Extensions (Legacy) → Bézier Inspector

회색 패널이 계속 뜨면:

  bash repair.sh

진단 로그가 필요하면:

  bash diagnostics.sh

파일 구성:

  com.ju.bezierinspector/        실제 CEP 확장 폴더
  install.sh                     추천 설치 스크립트
  repair.sh                      회색 패널 복구 스크립트
  uninstall.sh                   제거 스크립트
  diagnostics.sh                 진단 로그 출력
  scripts/build_zxp_self_signed.sh  self-signed ZXP 생성 스크립트
  scripts/install_zxp_with_upia.sh  UPIA로 ZXP 설치 스크립트
  tools/                         ZXPSignCmd를 넣는 위치
  zxp_out/                       ZXP 생성 위치
