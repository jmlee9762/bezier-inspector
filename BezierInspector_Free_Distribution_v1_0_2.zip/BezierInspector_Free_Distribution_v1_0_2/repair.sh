#!/bin/bash
set -euo pipefail
EXT_ID="com.ju.bezierinspector"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/$EXT_ID"
LOG="$HOME/Desktop/bezier_inspector_repair_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "Bézier Inspector repair"
echo "Log: $LOG"
echo ""

if [ ! -d "$EXT" ]; then
  echo "ERROR: Extension is not installed at: $EXT"
  echo "Run: bash install.sh"
  exit 1
fi

if pgrep -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "WARNING: Illustrator is running. Quit and restart it after this repair."
fi

echo "Enabling CEP PlayerDebugMode."
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
defaults write com.adobe.CSXS.13 PlayerDebugMode 1

echo "Removing quarantine and fixing permissions."
xattr -dr com.apple.quarantine "$EXT" 2>/dev/null || true
chmod -R u+rwX "$EXT" 2>/dev/null || true

echo "Clearing CEP cache."
rm -rf "$HOME/Library/Caches/CSXS/cep_cache" 2>/dev/null || true
rm -rf "$HOME/Library/Caches/CSXS/cep_cache_*" 2>/dev/null || true

echo "Checking duplicate installs."
find "$HOME/Library/Application Support/Adobe/CEP/extensions" \
     "/Library/Application Support/Adobe/CEP/extensions" \
     -maxdepth 2 -iname "*bezier*" -print 2>/dev/null || true

echo ""
echo "Repair complete. Restart Illustrator."
