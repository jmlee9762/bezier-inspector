#!/bin/bash
set -euo pipefail
EXT_ID="com.ju.bezierinspector"
TARGET_ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
BACKUP_ROOT="$HOME/Desktop/BezierInspector_Uninstalled_$(date +%Y%m%d_%H%M%S)"
LOG="$HOME/Desktop/bezier_inspector_uninstall_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

if pgrep -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "ERROR: Please quit Adobe Illustrator completely before uninstalling."
  exit 1
fi

mkdir -p "$BACKUP_ROOT"
FOUND=0
for OLD in \
  "$TARGET_ROOT/com.ju.bezierInspector" \
  "$TARGET_ROOT/com.ju.bezierinspector" \
  "$TARGET_ROOT/Bezier Inspector" \
  "$TARGET_ROOT/BezierInspector"; do
  if [ -e "$OLD" ]; then
    FOUND=1
    echo "Moving to backup: $OLD"
    mv "$OLD" "$BACKUP_ROOT/$(basename "$OLD")"
  fi
done

rm -rf "$HOME/Library/Caches/CSXS/cep_cache" 2>/dev/null || true
rm -rf "$HOME/Library/Caches/CSXS/cep_cache_*" 2>/dev/null || true

if [ "$FOUND" = "0" ]; then
  echo "No Bézier Inspector install found."
else
  echo "Uninstalled. Backup: $BACKUP_ROOT"
fi
