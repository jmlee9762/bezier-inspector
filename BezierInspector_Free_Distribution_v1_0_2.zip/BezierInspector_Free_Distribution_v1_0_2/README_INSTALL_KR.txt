# Bézier Inspector 설치 가이드 — install.sh 방식

이 방식이 무료 배포에서 가장 추천되는 방식입니다.
.app 설치기를 쓰지 않기 때문에 Apple Developer ID 경고를 피할 수 있습니다.

## 설치

1. Adobe Illustrator를 완전히 종료합니다.

2. ZIP을 압축 해제합니다.

3. Terminal을 엽니다.

4. 압축 해제한 폴더로 이동합니다. 예:

```bash
cd ~/Downloads/BezierInspector_Free_Distribution_v1_0_2
```

5. 설치 스크립트를 실행합니다.

```bash
bash install.sh
```

6. Illustrator를 재시작합니다.

7. 메뉴에서 엽니다.

```text
Window → Extensions (Legacy) → Bézier Inspector
```

## 회색 패널이 뜰 때

Illustrator를 종료한 뒤:

```bash
bash repair.sh
```

실행 후 Illustrator를 다시 시작합니다.

## 제거

```bash
bash uninstall.sh
```

## 진단 로그

```bash
bash diagnostics.sh
```

Desktop에 `bezier_inspector_diagnostics_...txt` 파일이 생성됩니다.
