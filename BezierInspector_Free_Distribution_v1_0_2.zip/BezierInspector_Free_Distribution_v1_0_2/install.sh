#!/bin/bash
set -euo pipefail

EXT_ID="com.ju.bezierinspector"
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_EXT="$PKG_DIR/$EXT_ID"
TARGET_ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
TARGET_DIR="$TARGET_ROOT/$EXT_ID"
LOG="$HOME/Desktop/bezier_inspector_install_$(date +%Y%m%d_%H%M%S).log"

exec > >(tee -a "$LOG") 2>&1

echo "Bézier Inspector installer"
echo "Log: $LOG"
echo ""

if pgrep -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "ERROR: Please quit Adobe Illustrator completely before installing."
  exit 1
fi

if [ ! -d "$SRC_EXT" ]; then
  echo "ERROR: Extension source folder not found: $SRC_EXT"
  echo "Make sure this script is next to the $EXT_ID folder."
  exit 1
fi

if [ ! -f "$SRC_EXT/CSXS/manifest.xml" ] || [ ! -f "$SRC_EXT/index.html" ]; then
  echo "ERROR: Extension folder is incomplete."
  echo "Expected: $SRC_EXT/CSXS/manifest.xml and $SRC_EXT/index.html"
  exit 1
fi

mkdir -p "$TARGET_ROOT"

BACKUP_ROOT="$HOME/Desktop/BezierInspector_Backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_ROOT"

# Remove old or duplicate installs. Keep a backup instead of deleting.
for OLD in \
  "$TARGET_ROOT/com.ju.bezierInspector" \
  "$TARGET_ROOT/com.ju.bezierinspector" \
  "$TARGET_ROOT/Bezier Inspector" \
  "$TARGET_ROOT/BezierInspector"; do
  if [ -e "$OLD" ]; then
    echo "Backing up old install: $OLD"
    mv "$OLD" "$BACKUP_ROOT/$(basename "$OLD")"
  fi
done

# Copy cleanly. ditto is preferred on macOS because it preserves resource handling better.
echo "Copying extension to: $TARGET_DIR"
if command -v ditto >/dev/null 2>&1; then
  ditto --noqtn "$SRC_EXT" "$TARGET_DIR"
else
  cp -R "$SRC_EXT" "$TARGET_DIR"
fi

# Remove macOS quarantine and fix permissions.
echo "Removing quarantine and fixing permissions."
xattr -dr com.apple.quarantine "$TARGET_DIR" 2>/dev/null || true
chmod -R u+rwX "$TARGET_DIR" 2>/dev/null || true

# Enable unsigned CEP extension loading for current/future Illustrator CEP runtimes.
echo "Enabling CEP PlayerDebugMode."
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
defaults write com.adobe.CSXS.13 PlayerDebugMode 1

# Clear CEP cache that can keep stale/blank panels alive.
echo "Clearing CEP cache."
rm -rf "$HOME/Library/Caches/CSXS/cep_cache" 2>/dev/null || true
rm -rf "$HOME/Library/Caches/CSXS/cep_cache_*" 2>/dev/null || true

# Basic verification.
echo ""
echo "Installed files:"
find "$TARGET_DIR" -maxdepth 2 -type f | sed "s|$HOME|~|" | sort

echo ""
echo "Install complete."
echo "1. Restart Illustrator."
echo "2. Open: Window → Extensions (Legacy) → Bézier Inspector"
echo ""
echo "If the panel is still gray, run: bash repair.sh"
