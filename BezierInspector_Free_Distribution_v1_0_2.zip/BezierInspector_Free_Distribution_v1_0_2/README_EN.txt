Bézier Inspector Free Distribution v1.0.2

This package provides two free installation paths:

1. Recommended: Terminal installer

   bash install.sh

   This copies the CEP extension into the correct Adobe CEP folder,
   removes quarantine attributes, fixes permissions, enables PlayerDebugMode,
   and clears the CEP cache.

2. Optional: self-signed ZXP

   Put Adobe ZXPSignCmd at:

   tools/ZXPSignCmd

   Then run:

   bash scripts/build_zxp_self_signed.sh

   The signed ZXP will be generated at:

   zxp_out/bezier_inspector.zxp

Open in Illustrator:

   Window → Extensions (Legacy) → Bézier Inspector

If the panel is gray:

   bash repair.sh

This kit does not include ZXPSignCmd and does not include a pre-signed ZXP.
A valid self-signed ZXP must be generated on a Mac with ZXPSignCmd.
