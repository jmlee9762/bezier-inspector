#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ZXP="${1:-$ROOT/zxp_out/bezier_inspector.zxp}"
UPIA="/Library/Application Support/Adobe/Adobe Desktop Common/RemoteComponents/UPI/UnifiedPluginInstallerAgent/UnifiedPluginInstallerAgent.app/Contents/MacOS/UnifiedPluginInstallerAgent"

if [ ! -f "$ZXP" ]; then
  echo "ERROR: ZXP not found: $ZXP"
  echo "Build it first: bash scripts/build_zxp_self_signed.sh"
  exit 1
fi
if [ ! -x "$UPIA" ]; then
  echo "ERROR: Adobe UPIA not found. Install/update Creative Cloud Desktop, or use ZXPInstaller."
  exit 1
fi
if pgrep -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "ERROR: Quit Adobe Illustrator first."
  exit 1
fi

"$UPIA" --install "$ZXP"
echo "Installed via UPIA. Restart Illustrator."
