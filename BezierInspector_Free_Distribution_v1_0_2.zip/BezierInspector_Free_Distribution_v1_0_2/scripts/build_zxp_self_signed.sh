#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXT_ID="com.ju.bezierinspector"
EXT_SRC="$ROOT/$EXT_ID"
OUT_DIR="$ROOT/zxp_out"
CERT_DIR="$ROOT/zxp_cert"
WORK_DIR="$(mktemp -d)"

# You can override these when running:
# CERT_PASSWORD="your-password" ZXP_SIGN_CMD="/path/to/ZXPSignCmd" bash scripts/build_zxp_self_signed.sh
CERT_PASSWORD="${CERT_PASSWORD:-bezier-inspector-self-signed}"
P12="$CERT_DIR/BezierInspectorSelfSigned.p12"
ZXP_OUT="$OUT_DIR/bezier_inspector.zxp"

cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT

find_zxpsign() {
  if [ -n "${ZXP_SIGN_CMD:-}" ] && [ -x "$ZXP_SIGN_CMD" ]; then
    echo "$ZXP_SIGN_CMD"; return 0
  fi
  if command -v ZXPSignCmd >/dev/null 2>&1; then
    command -v ZXPSignCmd; return 0
  fi
  for CAND in \
    "$ROOT/tools/ZXPSignCmd" \
    "$HOME/Downloads/ZXPSignCmd" \
    "$HOME/Downloads/ZXPSignCmd/ZXPSignCmd" \
    "$HOME/Downloads/ZXPSignCmd-64bit/ZXPSignCmd"; do
    if [ -x "$CAND" ]; then echo "$CAND"; return 0; fi
  done
  return 1
}

if [ ! -d "$EXT_SRC" ]; then
  echo "ERROR: Extension source folder not found: $EXT_SRC"
  exit 1
fi

mkdir -p "$OUT_DIR" "$CERT_DIR"

ZXP_SIGN="$(find_zxpsign || true)"
if [ -z "$ZXP_SIGN" ]; then
  cat <<'EOF'
ERROR: ZXPSignCmd was not found.

Put Adobe ZXPSignCmd here and make it executable:
  tools/ZXPSignCmd

Then run again:
  bash scripts/build_zxp_self_signed.sh

Alternative:
  ZXP_SIGN_CMD="/absolute/path/to/ZXPSignCmd" bash scripts/build_zxp_self_signed.sh
EOF
  exit 1
fi

echo "Using ZXPSignCmd: $ZXP_SIGN"

# Make a clean source copy. Avoid .DS_Store, __MACOSX and symlinks because they can break ZXP verification.
CLEAN_SRC="$WORK_DIR/$EXT_ID"
if command -v ditto >/dev/null 2>&1; then
  ditto --noqtn "$EXT_SRC" "$CLEAN_SRC"
else
  cp -R "$EXT_SRC" "$CLEAN_SRC"
fi
find "$CLEAN_SRC" -name ".DS_Store" -delete 2>/dev/null || true
find "$CLEAN_SRC" -name "__MACOSX" -type d -prune -exec rm -rf {} \; 2>/dev/null || true
if find "$CLEAN_SRC" -type l | grep -q .; then
  echo "ERROR: Symlinks found in extension source. Replace symlinks with real files first."
  find "$CLEAN_SRC" -type l
  exit 1
fi

if [ ! -f "$P12" ]; then
  echo "Creating self-signed certificate: $P12"
  "$ZXP_SIGN" -selfSignedCert US California "Ju" "Bezier Inspector" "$CERT_PASSWORD" "$P12" -validityDays 3650
else
  echo "Using existing certificate: $P12"
fi

rm -f "$ZXP_OUT"

echo "Signing ZXP with timestamp server..."
if ! "$ZXP_SIGN" -sign "$CLEAN_SRC" "$ZXP_OUT" "$P12" "$CERT_PASSWORD" -tsa http://time.certum.pl/; then
  echo "Timestamp signing failed. Retrying without timestamp."
  "$ZXP_SIGN" -sign "$CLEAN_SRC" "$ZXP_OUT" "$P12" "$CERT_PASSWORD"
fi

echo "Verifying ZXP."
"$ZXP_SIGN" -verify "$ZXP_OUT" -certinfo

echo ""
echo "Done: $ZXP_OUT"
echo "Install with ZXPInstaller, or with Adobe UPIA. See README_ZXP_INSTALL_KR.txt."
