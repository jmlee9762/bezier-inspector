# Bézier Inspector ZXP 가이드 — self-signed ZXP 방식

이 패키지는 ZXP 생성 스크립트를 포함합니다.
단, Adobe ZXPSignCmd 실행 파일은 포함하지 않았습니다.

## 1. ZXPSignCmd 준비

Adobe CEP Resources에서 macOS용 ZXPSignCmd를 받은 뒤, 실행 파일을 아래 위치에 넣습니다.

```text
tools/ZXPSignCmd
```

그리고 실행 권한을 줍니다.

```bash
chmod +x tools/ZXPSignCmd
```

또는 환경변수로 직접 경로를 지정할 수 있습니다.

```bash
ZXP_SIGN_CMD="/absolute/path/to/ZXPSignCmd" bash scripts/build_zxp_self_signed.sh
```

## 2. self-signed ZXP 생성

```bash
bash scripts/build_zxp_self_signed.sh
```

성공하면 아래 파일이 생성됩니다.

```text
zxp_out/bezier_inspector.zxp
```

스크립트는 처음 실행 시 self-signed certificate도 생성합니다.

```text
zxp_cert/BezierInspectorSelfSigned.p12
```

기본 인증서 비밀번호는 다음입니다.

```text
bezier-inspector-self-signed
```

원하면 이렇게 바꿀 수 있습니다.

```bash
CERT_PASSWORD="my-password" bash scripts/build_zxp_self_signed.sh
```

## 3. ZXPInstaller로 설치

1. Illustrator를 완전히 종료합니다.
2. ZXPInstaller를 엽니다.
3. `zxp_out/bezier_inspector.zxp` 파일을 ZXPInstaller 창에 드래그합니다.
4. 설치 완료 후 Illustrator를 재시작합니다.
5. 아래 메뉴에서 엽니다.

```text
Window → Extensions (Legacy) → Bézier Inspector
```

## 4. Adobe UPIA로 설치

Creative Cloud Desktop이 설치되어 있으면 UPIA가 있을 수 있습니다.

```bash
bash scripts/install_zxp_with_upia.sh
```

직접 명령을 쓰려면:

```bash
cd "/Library/Application Support/Adobe/Adobe Desktop Common/RemoteComponents/UPI/UnifiedPluginInstallerAgent/UnifiedPluginInstallerAgent.app/Contents/MacOS"
./UnifiedPluginInstallerAgent --install "/absolute/path/to/zxp_out/bezier_inspector.zxp"
```

## 5. ZXP 설치가 안 될 때

ZXPInstaller나 UPIA가 실패하면 추천 설치 방식으로 돌아갑니다.

```bash
bash install.sh
```

## 주의

Self-signed ZXP는 Apple Developer ID 서명과 다릅니다.
macOS Gatekeeper 경고 없는 .app/.dmg 배포를 만들려면 Apple Developer Program이 필요합니다.
