#!/bin/bash
set -euo pipefail
OUT="$HOME/Desktop/bezier_inspector_diagnostics_$(date +%Y%m%d_%H%M%S).txt"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/com.ju.bezierinspector"
{
  echo "Bézier Inspector Diagnostics"
  echo "Date: $(date)"
  echo "macOS: $(sw_vers 2>/dev/null || true)"
  echo ""
  echo "PlayerDebugMode:"
  defaults read com.adobe.CSXS.11 PlayerDebugMode 2>&1 || true
  defaults read com.adobe.CSXS.12 PlayerDebugMode 2>&1 || true
  defaults read com.adobe.CSXS.13 PlayerDebugMode 2>&1 || true
  echo ""
  echo "Installed extension files:"
  if [ -d "$EXT" ]; then
    find "$EXT" -maxdepth 3 -print | sort
    echo ""
    echo "Quarantine attributes:"
    xattr -lr "$EXT" 2>/dev/null | grep -i quarantine || echo "No quarantine attribute found."
  else
    echo "Not installed at $EXT"
  fi
  echo ""
  echo "Possible duplicate installs:"
  find "$HOME/Library/Application Support/Adobe/CEP/extensions" "/Library/Application Support/Adobe/CEP/extensions" -maxdepth 3 -iname "*bezier*" -print 2>/dev/null || true
  echo ""
  echo "Recent CEP/CSXS logs:"
  find "$HOME/Library/Logs/CEP" "$HOME/Library/Logs/CSXS" -type f -maxdepth 2 -mtime -7 -print 2>/dev/null || true
} > "$OUT"
echo "Diagnostics exported to: $OUT"
